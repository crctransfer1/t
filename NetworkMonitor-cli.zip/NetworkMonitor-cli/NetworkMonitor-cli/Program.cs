﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;


namespace NetworkMonitor_cli
{
    #region test region
    class main
    {

        static void Main(string[] args)
        {
            ServiceProvider wifi = new ServiceProvider("Wi-Fi");
            wifi.iperfTest();
            Console.WriteLine("press any key to continue");
            wifi.testData();
            Console.ReadLine();
            wifi.disableService();
            Console.WriteLine("press any key to continue");
            Console.ReadLine();
            wifi.enableService();
            Console.WriteLine("press any key to continue");
            Console.ReadLine();

        }
    }
    #endregion

    public class ServiceProvider
    {
        string iperfAddress = "142.92.80.9";
        string iperfPort = "5201";
        //testcode for list; storage of data objects
        List<StandardMonitoringData> test = new List<StandardMonitoringData>();
        StandardMonitoringData testobj = new StandardMonitoringData("1", "1", "1", "1ms", "1.1.11");
        iperfMonitoringData testiperfobj = new iperfMonitoringData("1", "1", "1", "1ms", "1.24142", "TEST");

        public string NAME;
        public ServiceProvider()
        {
            NAME = "null";
        }
        public ServiceProvider(string name)
        {
            NAME = name;
        }

        public void testData() {
            test.Add(testobj);
            test.Add(testiperfobj);
            test.ToString();
            test.ForEach(Console.WriteLine);
        }

        public void iperfTest()
        {
            Console.WriteLine("Performing iper3 test");
            Process iperfProcess = iperfProcessInstance("-c " + iperfAddress + " -p " + iperfPort);
            string iperfProcessOutput = iperfProcess.StandardOutput.ReadToEnd();
            iperfProcess.WaitForExit();
            Console.WriteLine("iperf3.exe output on " + NAME + ":\n" + iperfProcessOutput);
            StandardMonitoringData iperfData = extractStandardData(iperfProcessOutput);
            Console.WriteLine(iperfData);
        }

        public void disableService()
        {
            Console.WriteLine("Disabling " + NAME + "...");
            Process disable = netshProcessInstance(NAME + " DISABLED");
            disable.WaitForExit();
            Console.WriteLine(NAME + " Disabled.");
        }

        public void enableService()
        {
            Console.WriteLine("Enabling " + NAME + "...");
            Process enable = netshProcessInstance(NAME + " ENABLED");
            enable.WaitForExit();
            Console.WriteLine(NAME + " Enabled.");
        }
        public string speedTest()
        {
            return "";
        }

        //iperf process
        private Process iperfProcessInstance(string arguments)
        {
            Process iperfProcess = new Process();
            iperfProcess.StartInfo.FileName = "iperf3.exe";
            iperfProcess.StartInfo.Arguments = arguments;
            iperfProcess.StartInfo.UseShellExecute = false;
            iperfProcess.StartInfo.RedirectStandardOutput = true;
            iperfProcess.StartInfo.RedirectStandardError = true;
            iperfProcess.Start();
            return iperfProcess;
        }

        //netsh set interface
        private Process netshProcessInstance(string arguments)
        {
            Process netsh = new Process();
            netsh.StartInfo.FileName = "netsh.exe";
            netsh.StartInfo.Arguments = "interface set interface " + arguments;
            netsh.StartInfo.UseShellExecute = false;
            netsh.Start();
            return netsh;
        }

        //string extraction
        private StandardMonitoringData extractStandardData(string iperfProcessOutput)
        {
            string[] substring = iperfProcessOutput.Split("\n".ToCharArray());
            string[] extractedData = System.Text.RegularExpressions.Regex.Replace(substring[substring.Length - 4], @"\s+", " ").Split(' ');
            string transfer = extractedData[4] + " " + extractedData[5];
            string bandwidth = extractedData[6] + " " + extractedData[7];
            extractedData = System.Text.RegularExpressions.Regex.Replace(substring[1], @"\s+", " ").Split(' ');
            string ipaddress = extractedData[8];
            string port = extractedData[10];
            StandardMonitoringData iperfData = new StandardMonitoringData(bandwidth, transfer, transfer, "nodata", ipaddress);
            return iperfData;
        }

    }

    #region Standard Monitoring Data (Bandwidth, Downlink, Uplink, Latency, IP address)
    public class StandardMonitoringData
    {
        public string BW { get; set; }
        public string DL { get; set; }
        public string UL { get; set; }
        public string LT { get; set; }
        public string IPADDR { get; set; }


        public StandardMonitoringData()
        {
            BW = "0";
            DL = "0";
            UL = "0";
            LT = "0";
            IPADDR = "";
        }

        public StandardMonitoringData(string bw, string dl, string ul, string lt, string ipaddr)
        {
            BW = bw;
            DL = dl;
            UL = ul;
            LT = lt;
            IPADDR = ipaddr;
        }
        public override string ToString()
        {
            return String.Format("Bandwidth\tDownlink\tUplink\tLatency\tIP address\n{0}\t{1}\t{2}\t{3}\t{4}", BW, DL, UL, LT, IPADDR);
        }
    }
    #endregion

    #region iperf Monitoring Data (inherits StandardMonitoringData + test string)

    public class iperfMonitoringData : StandardMonitoringData
    {
        public string TEST { get; set; }
        public iperfMonitoringData(string bw, string dl, string ul, string lt, string ipaddr, string test)
        {
            BW = bw;
            DL = dl;
            UL = ul;
            LT = lt;
            IPADDR = ipaddr;
            TEST = test;
        }
        public override string ToString()
        {
            return String.Format("Bandwidth\tDownlink\tUplink\tLatency\tIP address\tTEST\n{0}\t{1}\t{2}\t{3}\t{4}\t{5}", BW, DL, UL, LT, IPADDR, TEST);
        }
    }
    #endregion
}
